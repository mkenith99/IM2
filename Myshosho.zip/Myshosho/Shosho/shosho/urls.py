#from django.contrib import admin
from django.urls import path
from . import views

app_name='shosho'
urlpatterns = [
   #path('admin/', admin.site.urls),
    #path('shosho/',include('shosho.urls'),namespace='shosho'),
     path('landing',views.LandingView.as_view(),name="landing_view"),
     path('register_customer',views.RegisterCustomerView.as_view(),name="register_customer_view"),
     path('register_product',views.RegisterProductView.as_view(),name="register_product_view"),
     path('dashboard_customer',views.CustomerDashboardView.as_view(),name="dashboard_customer_view"),
     path('dashboard_product',views.ProductDashboardView.as_view(),name="dashboard_product_view"),
     path('customer_buy',views.CustomerBuyView.as_view(),name='customer_buy_view'),
     path('index',views.IndexView.as_view(),name='index_view')
]  