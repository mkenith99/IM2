from django.apps import AppConfig


class ShoshoConfig(AppConfig):
    name = 'shosho'
