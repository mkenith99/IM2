from django import forms
from .models import *

class CustomerForm(forms.ModelForm):
	
	class Meta:
		model = Customer
		fields = ('person_firstname','person_lastname','brgy_address'
					, 'city_address', 'province_address', 'zip_address',
					'country_address','birthdate','status','gender',
					'mother_firstname','mother_lastname','mother_occupation',
					'father_firstname','father_lastname','father_occupation',
					'height','weight')
					
class ProductForm(forms.ModelForm):
	class Meta:
		model = Product
		fields = ('product_name','product_category','product_color','product_size','product_brand','product_price','product_stock')		