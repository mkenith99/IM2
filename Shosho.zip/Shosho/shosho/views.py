from django.shortcuts import render
from django.views.generic import View
from .forms import *
from .models import *
from django.http import HttpResponse
from django.core.files.storage import FileSystemStorage
from django.conf import settings
from django.shortcuts import redirect
from django.core.files import File

# Create your views here.
class LandingView(View):
    def get(self,request):
        #print('get')
        return render(request,'shosho/landing.html')
class IndexView(View):
    def get(self,request):
        #print('get')
        return render(request,'shosho/index.html')
class RegisterCustomerView(View):
    def get(self,request):
        #print('get')
        return render(request,'shosho/customerRegistration.html')

    def post(self,request):
        form=CustomerForm(request.POST,request.FILES)
        if form.is_valid():
            fname=request.POST.get("person_firstname")
            mname=request.POST.get("person_middlename")
            lname=request.POST.get("person_lastname")
            street=request.POST.get("street_address")
            brgy=request.POST.get("brgy_address")
            city=request.POST.get("city_address")
            prov=request.POST.get("province_address")
            zipC=request.POST.get("zip_address")
            country=request.POST.get("country_address")
            bDate=request.POST.get("birthdate")
            status=request.POST.get("status")
            gender=request.POST.get("gender")
            sFname=request.POST.get("spouseFName")
            sMname=request.POST.get("spouseMName")
            sLname=request.POST.get("spouseLName")
            sOccu=request.POST.get("spouseOccu")
            noChildren=request.POST.get("numChildren")
            mFname=request.POST.get("mother_firstname")
            mMname=request.POST.get("mother_middlename")
            mLname=request.POST.get("mother_lastname")
            mOccu=request.POST.get("mother_occupation")
            fFname=request.POST.get("father_firstname")
            fMname=request.POST.get("father_middlename")
            fLname=request.POST.get("father_lastname")
            fOccu=request.POST.get("father_occupation")
            height=request.POST.get("height")
            weight=request.POST.get("weight")
            religion=request.POST.get("religion")
            profile_picture=request.FILES.get('fileInput',None)
            try:
                noChildren=int(noChildren)
            except ValueError:
                noChildren='0'

            form=Customer(person_firstname=fname,person_middlename=mname,person_lastname=lname,street_address=street,
                            brgy_address=brgy,city_address=city,province_address=prov,zip_address=zipC,country_address=country,
                            birthdate=bDate,status=status,gender=gender,height=height,weight=weight,religion=religion,spouse_firstname=sFname,
                            spouse_middlename=sMname,spouse_lastname=sLname,spouse_occupation=sOccu,number_of_children=noChildren,
                            mother_firstname=mFname,mother_middlename=mMname,mother_lastname=mLname,mother_occupation=mOccu,
                            father_firstname=fFname,father_middlename=fMname,father_lastname=fLname,father_occupation=fOccu)
            form.save()
            if profile_picture is not None and profile_picture != '':
                form.profile_picture.save(profile_picture.name+str(form.id), File(profile_picture),save=True)
            return redirect('shosho:dashboard_customer_view')
        else:
            return HttpResponse("Failed")

class RegisterProductView(View):
    def get(self,request):
        return render(request,'shosho/productRegistration.html')

    def post(self,request):
        form=ProductForm(request.POST)
        if form.is_valid():
            pCategory=request.POST.get("product_category")
            pName=request.POST.get("product_name")
            pSize=request.POST.get("product_size")
            pColor=request.POST.get("product_color")
            pPrice=request.POST.get("product_price")
            pBrand=request.POST.get("product_brand")
            pStock=request.POST.get("product_stock")
            pPicture=request.FILES.get('fileInput',None)
            if pPicture is not None and pPicture != '':
                fs = FileSystemStorage()
                filename = fs.save(pPicture.name, pPicture)
                pPicture = fs.url(filename)
            form=Product(product_category=pCategory,product_name=pName,product_brand=pBrand,product_color=pColor,
                            product_size=pSize,product_price=pPrice,product_stock=pStock,product_picture=pPicture)
            form.save()
            return HttpResponse("Row added!")
        else:
            return HttpResponse("Failed!")

class ProductDashboardView(View):
    def get(self,request):
        products=Product.objects.all()
        context={
            'products':products
        }
        return render(request,'shosho/dashboard_product.html',context)
    
    def post(self,request):
        if request.method =='POST':
            form=ProductForm(request.POST)   
            if 'btnAdd' in request.POST:
                pCategory=request.POST.get("product_category")
                pName=request.POST.get("product_name")
                pSize=request.POST.get("product_size")
                pColor=request.POST.get("product_color")
                pPrice=request.POST.get("product_price")
                pBrand=request.POST.get("product_brand")
                pStock=request.POST.get("product_stock")
                pPicture=request.FILES.get('fileInput',None)
                if pPicture is not None and pPicture != '':
                    fs = FileSystemStorage()
                    filename = fs.save(pPicture.name, pPicture)
                    pPicture = fs.url(filename)
                form=Product(product_category=pCategory,product_name=pName,product_brand=pBrand,product_color=pColor,
                                product_size=pSize,product_price=pPrice,product_stock=pStock,product_picture=pPicture)
                form.save()
                return redirect('shosho:dashboard_product_view')
            elif 'btnUpdate' in request.POST:
                pId=request.POST.get("product_id")
                pCategory=request.POST.get("product_category")
                pName=request.POST.get("product_name")
                pSize=request.POST.get("product_size")
                pColor=request.POST.get("product_color")
                pPrice=request.POST.get("product_price")
                pBrand=request.POST.get("product_brand")
                pStock=request.POST.get("product_stock")
                pPicture=request.FILES.get('fileInput_update',None)
                pic=Product.objects.filter(sku=pId)[0].product_picture
                if pPicture is not None and pPicture != '':
                    fs = FileSystemStorage()
                    filename = fs.save(pPicture.name, pPicture)
                    pPicture = fs.url(filename)
                else:
                    pPicture=pic
                #print(pPicture)
                update_product=Product.objects.filter(sku=pId).update(product_category=pCategory,product_name=pName,product_brand=pBrand,product_color=pColor,product_size=pSize,product_price=pPrice,product_stock=pStock,product_picture=pPicture)
                print(update_product)
                return redirect('shosho:dashboard_product_view')
            elif 'btnDel' in request.POST:
                pId=request.POST.get("product_id")
                prodDelete = Product.objects.filter(sku=pId).update(isDeleted=1)
                return redirect('shosho:dashboard_product_view')
            else:
                return HttpResponse("not a submit button")
        else:
            return HttpResponse("METHOD != POST")

class CustomerDashboardView(View):
    def get(self,request):
        qsCustomers=Customer.objects.all()
        context = {
			'customers' : qsCustomers,
		}
        return render(request,'shosho/dashboard_customer.html',context)
    def post(self,request):
        if request.method=='POST':
            if 'btnUpdate' in request.POST:
                idNum=request.POST.get("id_num")
                fname=request.POST.get("person_firstname")
                mname=request.POST.get("person_middlename")
                lname=request.POST.get("person_lastname")
                street=request.POST.get("street_address")
                brgy=request.POST.get("brgy_address")
                city=request.POST.get("city_address")
                prov=request.POST.get("province_address")
                zipC=request.POST.get("zip_address")
                country=request.POST.get("country_address")
                bDate=request.POST.get("birthdate")
                status=request.POST.get("status")
                gender=request.POST.get("gender")
                sFname=request.POST.get("spouseFName")
                sMname=request.POST.get("spouseMName")
                sLname=request.POST.get("spouseLName")
                sOccu=request.POST.get("spouseOccu")
                noChildren=request.POST.get("numChildren")
                mFname=request.POST.get("mother_firstname")
                mMname=request.POST.get("mother_middlename")
                mLname=request.POST.get("mother_lastname")
                mOccu=request.POST.get("mother_occupation")
                fFname=request.POST.get("father_firstname")
                fMname=request.POST.get("father_middlename")
                fLname=request.POST.get("father_lastname")
                fOccu=request.POST.get("father_occupation")
                height=request.POST.get("height")
                weight=request.POST.get("weight")
                religion=request.POST.get("religion")
                changeFlag=request.POST.get("profileChanged")
                profile_picture=request.FILES.get('fileInput',None)
                try:
                    noChildren=int(noChildren)
                except ValueError:
                    noChildren='0'
                updatedCustomer=Customer.objects.filter(person_ptr_id=idNum).update(person_firstname=fname,person_middlename=mname,person_lastname=lname,street_address=street,
                            brgy_address=brgy,city_address=city,province_address=prov,zip_address=zipC,country_address=country,
                            birthdate=bDate,status=status,gender=gender,height=height,weight=weight,religion=religion,spouse_firstname=sFname,
                            spouse_middlename=sMname,spouse_lastname=sLname,spouse_occupation=sOccu,number_of_children=noChildren,
                            mother_firstname=mFname,mother_middlename=mMname,mother_lastname=mLname,mother_occupation=mOccu,
                            father_firstname=fFname,father_middlename=fMname,father_lastname=fLname,father_occupation=fOccu)
                if changeFlag=='T':
                    customer=Customer.objects.get(id=idNum)
                    if customer.profile_picture:
                        customer.profile_picture.delete()
                    if profile_picture is not None and profile_picture != '':
                        customer.profile_picture.save(profile_picture.name+idNum, File(profile_picture),save=True)
                
                return redirect('shosho:dashboard_customer_view')
            elif 'btnDelete' in request.POST:
                cId=request.POST.get("cIdNum")
                deleteCustomer=Customer.objects.filter(person_ptr_id=cId).update(isDeleted=1)
                return redirect('shosho:dashboard_customer_view')

class CustomerBuyView(View):
    def get(self,request):
        products=Product.objects.all()
        context={
            'products':products
        }
        return render(request,'shosho/customer_buy.html',context)
    def post(self,request):
        employee_id=request.POST.get('employee_id')
        print("Example ID")
        print(employee_id)
        name=[]
        customer_ordering=Customer.objects.get(id=employee_id)
        skus=request.POST.getlist('skus')
        quantities=request.POST.getlist('quantities')
        totalPrice=request.POST.get('totalPrice')
        transaction=Transaction( employeeId=customer_ordering,totalPrice=totalPrice)
        transaction.save()
        for i in range(len(skus)):
            qty=int(quantities[i])
            product=Product.objects.get(sku=skus[i])
            name.append(product.product_name)
            trans_prod=Transaction_Product(transactionId=transaction,productSKU=product,productQty=qty)
            trans_prod.save()
            Product.objects.filter(sku=skus[i]).update(product_stock=max(product.product_stock-qty,0))
       
        context={
            'name':name,
            'quantities':quantities,
            'totalPrice':totalPrice
            
            
        }
        return render(request,'shosho/transaction_view.html',context)

class ProductDeletedView(View):
    def get(self,request):
        products=Product.objects.all()
        context={
            'products':products
        }
        return render(request,'shosho/deleted_product.html',context)


class TransactionView(View):
    def get(self,request):
        return render(request,'shosho/transaction_view.html',context)

class CustomerDeletedView(View):
    def get(self,request):
        customers=Customer.objects.all()
        context={
            'customers':customers
        }
        return render(request,'shosho/deleted_customer.html',context)