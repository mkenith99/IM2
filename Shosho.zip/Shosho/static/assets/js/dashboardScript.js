$(document).ready(function() {
    $(".fr").click(function() {
        console.log("Blasdasdfad");
        $(this).parent().find('.fileInput').click();
      });
      $(".fileInput").on("change",function(){readURL(this)});
      function readURL(input){
        if (input.files && input.files[0]) {
          var reader = new FileReader();
          reader.onload = function (e) {
              $(input).parent().parent().find(".profileImage")
                  .attr('src', e.target.result)
                  .width(200);
                $(input).parent().find(".changeFlag").val("T");
          };
  
          reader.readAsDataURL(input.files[0]);
        }
      }
    var table = $('#dataTable').DataTable({
        dom: 'lBfrtip',
        buttons: true,
        buttons: [
            'excel'
        ]
    });
    $.fn.dataTable.ext.search.push(
        function(settings, data, dataIndex) {
            var min = $('#min').val() == "" ? null : new Date($('#min').val());
            var max = $('#max').val() == "" ? null : new Date($('#max').val());
            var startDate = new Date(data[0]);
            console.log(startDate);
            if (min == null && max == null) { return true; }
            if (min == null && startDate <= max) { return true; }
            if (max == null && startDate >= min) { return true; }
            if (startDate <= max && startDate >= min) { return true; }
            return false;
        }
    );
    var table = $('#dataTable').DataTable();
    // Event listener to the two range filtering inputs to redraw on input
    $('#min, #max').change(function() {
        table.draw();
    });
});