$(document).ready(function() {
    $(".fr").click(function() {
        console.log("Blasdasdfad");
        $(this).closest("input").click();
      });
      $(".fileInput").on("change",function(){readURL(this)});
      function readURL(input){
        if (input.files && input.files[0]) {
          var reader = new FileReader();
          reader.onload = function (e) {
              $('#profileImage')
                  .attr('src', e.target.result)
                  .width(200)
                  .height(200);
          };
  
          reader.readAsDataURL(input.files[0]);
        }
      }
    var table = $('#dataTable').DataTable({
        dom: 'lBfrtiBp',
        buttons: true,
        buttons: [
            'copy',
            'excel',
            'csv',
            'pdf'
        ]
    });
    $.fn.dataTable.ext.search.push(
        function(settings, data, dataIndex) {
            var min = $('#min').val() == "" ? null : new Date($('#min').val());
            var max = $('#max').val() == "" ? null : new Date($('#max').val());
            var startDate = new Date(data[0]);
            if (min == null && max == null) { return true; }
            if (min == null && startDate <= max) { return true; }
            if (max == null && startDate >= min) { return true; }
            if (startDate <= max && startDate >= min) { return true; }
            return false;
        }
    );
    var table = $('#dataTable').DataTable();
    // Event listener to the two range filtering inputs to redraw on input
    $('#min, #max').change(function() {
        table.draw();
    });
});